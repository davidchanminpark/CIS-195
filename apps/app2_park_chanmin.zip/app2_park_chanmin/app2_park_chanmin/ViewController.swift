//
//  ViewController.swift
//  app2_park_chanmin
//
//  Created by David Park on 9/17/20.
//  Copyright © 2020 Park. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var gameName: UILabel!
    @IBOutlet weak var playerOneScore: UILabel!
    @IBOutlet weak var playerTwoScore: UILabel!
    @IBOutlet weak var gameStatus: UILabel!
    
    @IBOutlet var collectionButtons: Array<UIButton>?
    

    
    @IBOutlet var buttons: [UIButton]!
    
    @IBAction func clear(_ sender: Any) {
        for button in buttons {
            button.setImage(UIImage(named: "mark-none"), for: .normal)
        }
    }
    
    
    func buttonFunc(_ sender: UIButton) {
        let random = Bool.random()
        if (random) {
            sender.setImage(UIImage(named: "mark-x"), for: .normal)
        } else {
            sender.setImage(UIImage(named: "mark-o"), for: .normal)
        }
        print(sender.tag)
        gameName.text = "hello"
        playerOneScore.text = "hi"
        playerTwoScore.text = "wassup"
        gameStatus.text = "wfe"
    }

    @IBAction func clickButtonOne(_ sender: UIButton) {
        buttonFunc(sender)
    }
    
    @IBAction func clickButtonTwo(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonThree(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonFour(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonFive(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonSix(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonSeven(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonEight(_ sender: UIButton) {
        buttonFunc(sender)
    }
    @IBAction func clickButtonNine(_ sender: UIButton) {
        buttonFunc(sender)
    }
}

