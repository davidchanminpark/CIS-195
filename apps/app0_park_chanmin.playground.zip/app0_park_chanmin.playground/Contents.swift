import UIKit

// App 0
let name = "Chanmin Park"
let pennId = 26170147

print("Hello World! My name is \(name) and my pennId is \(pennId)")
